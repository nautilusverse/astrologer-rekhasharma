(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_page_cf51c7e1.js",
  "static/chunks/node_modules_78031760._.js"
],
    source: "dynamic"
});
